Smart Construction Semantic Pipeline - STL package
Project: 二居室 · 80㎡（真实户型参考）
Scale: 1 model unit = 50 mm
01_floor.stl: floor layer
02_walls.stl: unified wall layer (multi-shell prototype)
03_furniture.stl: furniture layer
04_semantic_manifest.json: semantic room mapping for downstream tracking.

Production note: before physical printing, perform Boolean union/manifold repair, tolerance checks and slicer validation.
