# Simulation bundle

Project: 三居室 · 120.8㎡（真实户型参考）

- `model.obj` / `model.mtl`: generic 3D mesh in meters.
- `semantic_scene.json`: semantic room and furniture data.
- `simulation_scene.json`: generic entity scene description.
- `model.sdf`: basic Gazebo-compatible model wrapper.

Unity / Isaac Sim can import `model.obj`; preserve `semantic_scene.json` as a sidecar and map room IDs into engine-side tags/components.
